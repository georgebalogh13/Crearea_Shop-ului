Înainte de rularea fișierului db.sql, vă rog să creați baza de date shopapp_spring.

Vă mulțumesc.