package com.shop.model;

public class Sale {

    private int id;
    private int productId;
    private int buyerId;
    private int units;
    private double price;


    public Sale(int id, int productId, int buyerId, int units, double price) {
        this.id = id;
        this.productId = productId;
        this.buyerId = buyerId;
        this.units = units;
        this.price = price;
    }
    public Sale(){}

    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }

    public int getProductId() {
        return productId;
    }

    public void setProductId(int productId) {
        this.productId = productId;
    }

    public int getBuyerId() {
        return buyerId;
    }

    public void setBuyerId(int buyerId) {
        this.buyerId = buyerId;
    }

    public int getUnits() {
        return units;
    }

    public void setUnits(int units) {
        this.units = units;
    }

    public double getPrice() {
        return price;
    }

    public void setPrice(double price) {
        this.price = price;
    }

    @Override
    public String toString() {
        return "Sale{" +
                "id=" + id +
                ", productId=" + productId +
                ", buyerId=" + buyerId +
                ", units=" + units +
                ", price=" + price +
                '}';
    }
}
