package com.shop.controller;

import com.shop.dao.BuyerDAO;
import com.shop.dao.ProductDAO;
import com.shop.model.Buyer;
import com.shop.model.Product;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;

import java.util.List;

@Controller
public class BuyerController {


    @RequestMapping( value = "/buyers",method = RequestMethod.GET)
    public String allBuyers(Model map){
        BuyerDAO dao = new BuyerDAO();
        List<Buyer> allBuyers = dao.getAllBuyers();
        map.addAttribute("buyers", allBuyers);
        return "buyers";
    }

    @RequestMapping(value = "/buyer", method = RequestMethod.GET)
    public String addBuyer(Model map){
        map.addAttribute("buyer", new Buyer());
        return "add-buyer";
    }

    @RequestMapping(value = "/buyer/add", method = RequestMethod.POST)
    public String saveBuyer(@ModelAttribute("buyer") Buyer buyer) {
        BuyerDAO dao = new BuyerDAO();
        dao.save(buyer);
        return "redirect:/buyers";
    }

    @RequestMapping(value = "/buyer/delete/{id}", method = RequestMethod.GET)
    public String deleteBuyer(@PathVariable("id") int id){
        final BuyerDAO dao = new BuyerDAO();
        dao.delete(id);
        return "redirect:/buyers";
    }

    @RequestMapping(value="/edit/buyer/{id}")
    public String editBuyer(@PathVariable int id, Model m){
        final BuyerDAO dao = new BuyerDAO();
        Buyer b=dao.getBuyerById(id);
        m.addAttribute("buyer",b);
        return "edit-buyer";
    }

    @RequestMapping(value="/buyer/saveBuyer",method = RequestMethod.POST)
    public String editBuyerSave(@ModelAttribute("buyer") Buyer buyer){
        final BuyerDAO dao = new BuyerDAO();
        dao.update(buyer);
        return "redirect:/buyers";
    }

}
