package com.shop.controller;

import com.shop.dao.BuyerDAO;
import com.shop.dao.ProductDAO;
import com.shop.dao.SalesDAO;
import com.shop.model.Buyer;
import com.shop.model.Product;
import com.shop.model.Sale;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;

import java.util.ArrayList;
import java.util.List;

@Controller
public class SalesControlelr {


    @RequestMapping( value = "/sales",method = RequestMethod.GET)
    public String allSales(Model map){
        SalesDAO dao = new SalesDAO();
        List<Sale> allBuyers = dao.getAllSales();
        map.addAttribute("sales", allBuyers);
        return "sales";
    }

    @RequestMapping(value = "/sale", method = RequestMethod.GET)
    public String addSale(Model map){
        BuyerDAO buyerDAO = new BuyerDAO();
        ProductDAO productDAO = new ProductDAO();
        final List<Buyer> buyers = buyerDAO.getAllBuyers();
        final List<Product> products = productDAO.getAllProducts();

        map.addAttribute("buyers", buyers);
        map.addAttribute("products", products);
        map.addAttribute("sale", new Sale());
        return "add-sale";
    }

    @RequestMapping(value = "/sale/add", method = RequestMethod.POST)
    public String saveSale(@ModelAttribute("sale") Sale sale) throws Exception {
        final SalesDAO salesDAO = new SalesDAO();
        salesDAO.orderSale(sale);
        return "redirect:/sales";
    }

    @RequestMapping( value = "/sales/view/{productId}/{buyerId}",method = RequestMethod.GET)
    public String viewProduct(Model map, @PathVariable int productId, @PathVariable int buyerId){
        ProductDAO productDAO = new ProductDAO();
        final BuyerDAO buyerDAO = new BuyerDAO();
        final Product product = productDAO.getProductById(productId);
        final Buyer buyer = buyerDAO.getBuyerById(buyerId);

        map.addAttribute("product", product);
        map.addAttribute("buyer", buyer);


        return "view-sale";
    }
}
