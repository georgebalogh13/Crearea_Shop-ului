package com.shop.controller;

import com.shop.dao.ProductDAO;
import com.shop.model.Product;
import org.springframework.stereotype.Controller;
import org.springframework.ui.ModelMap;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;

import java.sql.SQLException;
import java.util.List;

@Controller
public class HelloController {



    @RequestMapping(value = "/", method = RequestMethod.GET)
    public String hello(ModelMap modelMap) throws SQLException, ClassNotFoundException {
        return "index";
    }
}
