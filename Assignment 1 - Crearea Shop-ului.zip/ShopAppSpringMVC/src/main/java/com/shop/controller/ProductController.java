package com.shop.controller;

import com.shop.dao.ProductDAO;
import com.shop.model.Product;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.ui.ModelMap;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;

import java.util.List;

@Controller
public class ProductController {


    @RequestMapping( value = "/products",method = RequestMethod.GET)
    public String allProducts(Model map){
        ProductDAO dao = new ProductDAO();
        List<Product> allProducts = dao.getAllProducts();
        map.addAttribute("products", allProducts);
        return "products";
    }



    @RequestMapping(value = "/product", method = RequestMethod.GET)
    public String addProduct(Model map){
        map.addAttribute("product", new Product());
        return "add-product";
    }

    @RequestMapping(value = "/product/add", method = RequestMethod.POST)
    public String saveProduct(@ModelAttribute("product") Product product) {
        ProductDAO productDAO = new ProductDAO();
        productDAO.save(product);
        return "redirect:/products";
    }

    @RequestMapping(value = "/product/delete/{id}", method = RequestMethod.GET)
    public String deleteProduct(@PathVariable("id") int id){
        final ProductDAO productDAO = new ProductDAO();
        productDAO.delete(id);
        return "redirect:/products";
    }

    @RequestMapping(value="/edit/product/{id}")
    public String edit(@PathVariable int id, Model m){
        final ProductDAO dao = new ProductDAO();
        Product p=dao.getProductById(id);
        m.addAttribute("product",p);
        return "edit-product";
    }

    @RequestMapping(value="/product/saveProduct",method = RequestMethod.POST)
    public String editProductSave(@ModelAttribute("product") Product product){
        final ProductDAO dao = new ProductDAO();
        dao.update(product);
        return "redirect:/products";
    }

}
