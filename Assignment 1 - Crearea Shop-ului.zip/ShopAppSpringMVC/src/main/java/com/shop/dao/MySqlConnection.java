package com.shop.dao;

import java.sql.*;

public class MySqlConnection {

    public static Connection getConnection() throws ClassNotFoundException, SQLException {
        Class.forName("com.mysql.jdbc.Driver");
        System.out.println("connected");
        return DriverManager.getConnection(
                "jdbc:mysql://localhost:3306/shopapp_spring","root","P0rt013!@#$");

    }



}
