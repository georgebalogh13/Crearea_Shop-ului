package com.shop.dao;

import com.shop.model.Product;

import java.sql.*;
import java.util.ArrayList;
import java.util.List;

import static com.shop.dao.MySqlConnection.getConnection;

public class ProductDAO {

    public List<Product> getAllProducts()  {
        ArrayList<Product> products = new ArrayList<>();
        try(Connection con = getConnection()){
            Statement stm = con.createStatement();
            ResultSet rs = stm.executeQuery("select * from products");
            while(rs.next()){
                Product p = createProduct(rs);
                products.add(p);
            }
        } catch (SQLException throwables) {
            throwables.printStackTrace();
        } catch (ClassNotFoundException e) {
            e.printStackTrace();
        }
        return products;
    }

    private Product createProduct(ResultSet rs) throws SQLException {
        return new Product(rs.getInt(1), rs.getString(2), rs.getDouble(3), rs.getInt(4));
    }


    public void save(Product product) {
        try(Connection connection = getConnection()){
            String sql = "insert into products(name, price, quantity) VALUES (?, ?, ?)";
            PreparedStatement ps = connection.prepareStatement(sql);
            ps.setString(1, product.getName());
            ps.setDouble(2, product.getPrice());
            ps.setInt(3, product.getQuantity());

            ps.executeUpdate();

        } catch (SQLException throwables) {
            throwables.printStackTrace();
        } catch (ClassNotFoundException e) {
            e.printStackTrace();
        }
    }

    public void delete(int id) {
        try(final Connection con = getConnection()){
            Statement stm = con.createStatement();
            stm.executeUpdate("delete from products where id = " + id);
        } catch (SQLException throwables) {
            throwables.printStackTrace();
        } catch (ClassNotFoundException e) {
            e.printStackTrace();
        }
    }

    public Product getProductById(int id) {
        Product p = null;

        try(final Connection con = getConnection()){
            Statement stm = con.createStatement();
            ResultSet rs = stm.executeQuery("select * from products where id =" + id);
            while(rs.next()){
                 p = createProduct(rs);

            }
        } catch (SQLException throwables) {
            throwables.printStackTrace();
        } catch (ClassNotFoundException e) {
            e.printStackTrace();
        }
        return p;
    }

    public void update(Product product) {
        try(final Connection con = getConnection()){
            System.out.println(product.getId());
            String sql = "update products set name =?,price=?,quantity=? where id =?";
            final PreparedStatement ps = con.prepareStatement(sql);
            ps.setString(1, product.getName());
            ps.setDouble(2, product.getPrice());
            ps.setInt(3, product.getQuantity());
            ps.setInt(4, product.getId());
            System.out.println(sql);
            ps.executeUpdate();
        } catch (SQLException throwables) {
            throwables.printStackTrace();
        } catch (ClassNotFoundException e) {
            e.printStackTrace();
        }
    }
}
