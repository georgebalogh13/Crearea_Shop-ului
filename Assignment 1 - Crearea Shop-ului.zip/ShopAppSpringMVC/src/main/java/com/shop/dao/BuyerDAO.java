package com.shop.dao;

import com.shop.model.Buyer;
import com.shop.model.Product;

import java.sql.*;
import java.util.ArrayList;
import java.util.List;

import static com.shop.dao.MySqlConnection.getConnection;

public class BuyerDAO {
    public List<Buyer> getAllBuyers() {
        ArrayList<Buyer> buyers = new ArrayList<>();
        try(Connection con = getConnection()){
            Statement stm = con.createStatement();
            ResultSet rs = stm.executeQuery("select * from buyers");
            while(rs.next()){
                Buyer p = createBuyer(rs);
                buyers.add(p);
            }
        } catch (SQLException throwables) {
            throwables.printStackTrace();
        } catch (ClassNotFoundException e) {
            e.printStackTrace();
        }
        return buyers;
    }

    private Buyer createBuyer(ResultSet rs) throws SQLException {
            return new Buyer(rs.getInt(1), rs.getString(2), rs.getString(3), rs.getString(4), rs.getString(5));

    }

    public void save(Buyer buyer) {
        try(Connection connection = getConnection()){
            String sql = "insert into buyers(first_name, last_name, email, address) VALUES (?, ?, ?, ?)";
            PreparedStatement ps = connection.prepareStatement(sql);
            ps.setString(1, buyer.getFirstName());
            ps.setString(2, buyer.getLastName());
            ps.setString(3, buyer.getEmail());
            ps.setString(4, buyer.getAddress());

            ps.executeUpdate();

        } catch (SQLException throwables) {
            throwables.printStackTrace();
        } catch (ClassNotFoundException e) {
            e.printStackTrace();
        }
    }

    public Buyer getBuyerById(int id) {
        Buyer b = null;

        try(final Connection con = getConnection()){
            Statement stm = con.createStatement();
            ResultSet rs = stm.executeQuery("select * from buyers where id =" + id);
            while(rs.next()){
                b = createBuyer(rs);

            }
        } catch (SQLException throwables) {
            throwables.printStackTrace();
        } catch (ClassNotFoundException e) {
            e.printStackTrace();
        }
        return b;
    }

    public void update(Buyer buyer) {

        try(final Connection con = getConnection()){
            System.out.println(buyer.getId());
            String sql = "update buyers set first_name =?,last_name=?,email=?, address=? where id =?";
            final PreparedStatement ps = con.prepareStatement(sql);
            ps.setString(1, buyer.getFirstName());
            ps.setString(2, buyer.getLastName());
            ps.setString(3, buyer.getEmail());
            ps.setString(4, buyer.getAddress());
            ps.setInt(5, buyer.getId());

            System.out.println(sql);
            ps.executeUpdate();
        } catch (SQLException throwables) {
            throwables.printStackTrace();
        } catch (ClassNotFoundException e) {
            e.printStackTrace();
        }
    }

    public void delete(int id) {
        try(final Connection con = getConnection()){
            Statement stm = con.createStatement();
            stm.executeUpdate("delete from buyers where id = " + id);
        } catch (SQLException throwables) {
            throwables.printStackTrace();
        } catch (ClassNotFoundException e) {
            e.printStackTrace();
        }
    }
}
