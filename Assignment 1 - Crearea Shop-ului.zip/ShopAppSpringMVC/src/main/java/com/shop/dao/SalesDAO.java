package com.shop.dao;

import com.shop.model.Product;
import com.shop.model.Sale;

import java.sql.*;
import java.util.ArrayList;
import java.util.List;

import static com.shop.dao.MySqlConnection.getConnection;

public class SalesDAO {
    public List<Sale> getAllSales() {
        ArrayList<Sale> sales = new ArrayList<>();
        try(Connection con = getConnection()){
            Statement stm = con.createStatement();
            ResultSet rs = stm.executeQuery("select * from sales");
            while(rs.next()){
                Sale p = createSale(rs);
                sales.add(p);
            }
        } catch (SQLException throwables) {
            throwables.printStackTrace();
        } catch (ClassNotFoundException e) {
            e.printStackTrace();
        }
        return sales;
    }

    private Sale createSale(ResultSet rs) throws SQLException {
        return new Sale(rs.getInt(1), rs.getInt(2), rs.getInt(3), rs.getInt(4), rs.getDouble(5));
    }

    public void orderSale(Sale sale) throws Exception {
        final ProductDAO productDAO = new ProductDAO();
        final Product product = productDAO.getProductById(sale.getProductId());
        if(product.getQuantity() < sale.getUnits()){
            throw new Exception("Too many prducts or the product is out of stock");
        }
        product.setQuantity(product.getQuantity() - sale.getUnits());
        productDAO.update(product);
        sale.setPrice(sale.getUnits() * product.getPrice());
        try(Connection connection = getConnection()){
            String sql = "insert into sales(product_id, buyer_id, units, price) VALUES (?, ?, ?, ?)";
            PreparedStatement ps = connection.prepareStatement(sql);
            ps.setInt(1, sale.getProductId());
            ps.setInt(2, sale.getBuyerId());
            ps.setInt(3, sale.getUnits());
            ps.setDouble(4, sale.getPrice());

            ps.executeUpdate();

        } catch (SQLException throwables) {
            throwables.printStackTrace();
        } catch (ClassNotFoundException e) {
            e.printStackTrace();
        }

    }
}
